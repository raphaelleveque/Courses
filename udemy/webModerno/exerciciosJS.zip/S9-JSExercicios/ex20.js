const calcularArea = (base, altura) => base * altura / 2

console.log(calcularArea(10, 15))