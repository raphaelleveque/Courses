function receberPrimeiroEUltimoElemento(arr) {
    return [arr[0], arr[arr.length - 1]]
}

console.log(receberPrimeiroEUltimoElemento([7,14,"olá"]))