function simboloMais(num) {
    return "+".repeat(num)
}

console.log(simboloMais(5))