function sayHello(name) {
    console.log("Olá, " + name + "!")
}

sayHello("Raphael")