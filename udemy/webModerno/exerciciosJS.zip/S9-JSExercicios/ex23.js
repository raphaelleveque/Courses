function contarPalavras(str) {
    return str.split(' ').length
}

console.log(contarPalavras("Eu sou Raphael"))