function anosEmDias(anos) {
    return anos * 365
}

console.log(anosEmDias(20))