const menorNumero = arr => Math.min(...arr)

console.log(menorNumero([5, 29, 1, -6, 3]))
