#include "Array.h"

int main() {
    int n = 7;
    Array<int> arr(n, -1);
    arr.Display();


    return 0;
}
