#include "Array.h"

template<typename T>
Array<T>::Array(int sz, int initialized) {
    max_size = sz;
    length = sz;
    A = new T[max_size];
    for (int i = 0; i < sz; ++i) {
        A[i] = initialized;
    }
}

template<typename T>
Array<T>::Array() {
    max_size = 2;
    length = 0;
    A = new T[max_size];
    for (int i = 0; i < 2; ++i) {
        A[i] = 0;
    }
}

template <typename T>
Array<T>::~Array() {
    delete []A;
}

template<typename T>
void Array<T>::Display() {
    for (int i = 0; i < length; ++i) {
        cout << A[i] << " ";
    }
    cout << endl;
}

template<typename T>
int &Array<T>::operator[](int index) {
    if (index >= max_size) {
        cout << "Array index out of bound, exiting";
        exit(0);
    }
    return A[index];
}
