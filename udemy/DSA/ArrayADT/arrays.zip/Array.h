#ifndef ARRAYADT_ARRAY_H
#define ARRAYADT_ARRAY_H
#include <iostream>
using namespace std;


template <typename T>
class Array {
private:
    T *A;
    int max_size;
    int length;
public:
    Array(int sz, int initialized = 0);

    Array();

    ~Array();

    int& operator[](int index);

    void Display();
};

#endif //ARRAYADT_ARRAY_H
